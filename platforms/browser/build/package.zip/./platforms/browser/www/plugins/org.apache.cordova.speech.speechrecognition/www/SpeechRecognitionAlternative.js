cordova.define("org.apache.cordova.speech.speechrecognition.SpeechRecognitionAlternative", function(require, exports, module) { var SpeechRecognitionAlternative = function() {
    this.transcript = null;
    this.confidence = 0.0;
};

module.exports = SpeechRecognitionAlternative;

});
