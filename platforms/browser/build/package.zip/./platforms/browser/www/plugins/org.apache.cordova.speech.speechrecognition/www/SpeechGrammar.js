cordova.define("org.apache.cordova.speech.speechrecognition.SpeechGrammar", function(require, exports, module) { var SpeechGrammar = function() {
    this.src;
    this.weight;
};

module.exports = SpeechGrammar;

});
